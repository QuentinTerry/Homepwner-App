package com.bignerdranch.android.homepwner;

import android.content.Context;


import java.io.File;
import java.util.List;
import java.lang.String;
import java.util.ArrayList;
import  java.util.Random;
import java.util.UUID;


public class ItemLab {


    private static ItemLab sItemLab;
    private Context mContext;
    private List<Item> mItems;

    public static ItemLab get(Context context) {
        if (sItemLab == null) {
            sItemLab = new ItemLab(context);
        }
        return sItemLab;
    }

    private ItemLab(Context context) {
        mItems = new ArrayList<>();

        for (int i = 0; i < 3; i++) {
            String nouns = "Rusty Fluffy Shiny";
            String adj = "Bear Spork Mac";
            String[] arraynouns = nouns.split(" ");
            String[] arrayadj = adj.split(" ");
            int randomNum = new Random().nextInt(61) + 20;
            int randN = (int) ( Math.random() * arraynouns.length);
            int randA = (int) ( Math.random() * arrayadj.length);
            String randnoun = arraynouns[randN];
            String randadj = arrayadj[randA];

            String S = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuffer s = new StringBuffer();
            Random rnd = new Random();
            while (s.length() < 8) { // length of the random string.
                int index = (int) (rnd.nextFloat() * S.length());
                s.append(S.charAt(index));
            }
            String serial = s.toString();
            Integer test = randomNum + i;
            Item item = new Item();
            item.setTitle(randnoun + " " + randadj);
            item.setValue(test.toString());
            item.setSerial(serial);
            item.setSolved(i % 2 == 0); // Every other one

            mItems.add(item);

        }


    }

    public void additem(Item c) {
        mItems.add(c);
    }

    public List<Item> getItems() {
        return mItems;
    }
    public Item getItem(UUID id) {
        for (Item item : mItems) {
            if (item.getId().equals(id)) {
                return item;
            }
        }
        return null;
    }

    public File getPhotoFile(Item item) {

        File filesDir = mContext.getFilesDir();
        return new File(filesDir, item.getPhotoFilename());
    }


}
