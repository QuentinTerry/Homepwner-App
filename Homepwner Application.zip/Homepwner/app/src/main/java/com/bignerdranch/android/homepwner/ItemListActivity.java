package com.bignerdranch.android.homepwner;
import android.content.Intent;
import android.support.v4.app.Fragment;


public class ItemListActivity extends SingleFragmentActivity implements ItemListFragment.Callbacks, HomeFragment.Callbacks{
    @Override
    protected Fragment createFragment() {
        return new ItemListFragment();
    }
   // public static final String EXTRA_ITEM_ID = "com.bignerdranch.android.homepwner.item_id";

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_masterdetail;
    }

    @Override
    public void onItemSelected(Item item) {
        if (findViewById(R.id.detail_fragment_container)
                == null) {
            Intent intent =
                   ItemPagerActivity.newIntent(this,    item.getId());
            startActivity(intent);
        } else {
            Fragment newDetail =
                    HomeFragment.newInstance(item.getId());
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.detail_fragment_container, newDetail)
                    .commit();
        }

    }
    public void onItemUpdated(Item item) {
        ItemListFragment listFragment =
                (ItemListFragment)
                        getSupportFragmentManager()
                                .findFragmentById(R.id.fragmentContainer);
        listFragment.updateUI();
    }



}
