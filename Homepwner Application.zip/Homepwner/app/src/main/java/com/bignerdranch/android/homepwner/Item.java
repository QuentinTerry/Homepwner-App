package com.bignerdranch.android.homepwner;

import java.util.Date;
import java.util.UUID;

public class Item {
    private UUID mId;
    private String mTitle;
    private String mValue;
    private String mSerial;
    private Date mDate;
    private boolean mSolved;
    private String mSuspect;
    public Item() {
        mId = UUID.randomUUID();
        mDate = new Date();
    }
    public UUID getId() {
        return mId;
    }
    public String getTitle() {
        return mTitle;
    }
    public void setTitle(String title) {
        mTitle = title;
    }
    public String  getValue() {
        return   mValue;
    }
    public void setValue(String value) {
        mValue =   value;
    }
    public String getSerial() {
        return mSerial;
    }
    public void setSerial(String serial) {
        mSerial = serial;
    }
    public Date getDate() {
        return mDate;
    }
    public void setDate(Date date) {
        mDate = date;
    }
    public boolean isSolved() {
        return mSolved;
    }
    public void setSolved(boolean solved) {
        mSolved = solved;
    }
    public String getSuspect() {
        return mSuspect;
    }
    public void setSuspect(String suspect) {
        mSuspect = suspect;
    }

    public String getPhotoFilename() {
        return "IMG_" + getId().toString() + ".jpg";
    }

}


