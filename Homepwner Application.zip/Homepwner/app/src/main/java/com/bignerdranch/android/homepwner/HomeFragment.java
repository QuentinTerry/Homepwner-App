package com.bignerdranch.android.homepwner;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.FileProvider;
import android.text.*;
import android.text.format.DateFormat;
import android.view.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toolbar;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.UUID;

public class HomeFragment extends Fragment {

    private static final String ARG_ITEM_ID =
            "item_id";

    private static final String DIALOG_DATE =
            "DialogDate";

    private static final int REQUEST_DATE = 0;

    private static final int REQUEST_PHOTO= 2;


    private Item mitem;
    private File mPhotoFile;
    private EditText mTitleField;
    private EditText mSerialField;
    private EditText mValueField;
    private Button mDateButton;
    private Button mReportButton;
    private ImageButton mPhotoButton;
    private ImageView mPhotoView;
    private Callbacks mCallbacks;
    /**
     * Required interface for hosting activities
     */
    public interface Callbacks {
        void onItemUpdated(Item item);
    }



    public static HomeFragment newInstance(UUID itemId) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_ITEM_ID, itemId);
        HomeFragment fragment = new HomeFragment();
        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mCallbacks = (Callbacks) context;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mitem = new Item();
        UUID itemId = (UUID)getArguments().getSerializable(ARG_ITEM_ID);
        mitem = ItemLab.get(getActivity()).getItem(itemId);
      //  mPhotoFile = ItemLab.get(getActivity()).getPhotoFile(mitem);

    }
    @Override
    public void onDetach() {
        super.onDetach();
        mCallbacks = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home, parent, false);
        mTitleField = (EditText)v.findViewById(R.id.item_name);
        mTitleField.setText(mitem.getTitle());
        mTitleField.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(
                    CharSequence c, int start, int before, int count) {
                mitem.setTitle(c.toString());
            }
            public void beforeTextChanged(
                    CharSequence c, int start, int count, int after) {
                // This space intentionally left blank
            }
            public void afterTextChanged(Editable c) {
                // This one too
            }
        });


        mSerialField = (EditText)v.findViewById(R.id.item_serial);
        mSerialField.setText(mitem.getSerial());
        mSerialField.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(
                    CharSequence c, int start, int before, int count) {
                mitem.setSerial(c.toString());
            }
            public void beforeTextChanged(
                    CharSequence c, int start, int count, int after) {
                // This space intentionally left blank
            }
            public void afterTextChanged(Editable c) {
                // This one too
            }
        });

        mValueField = (EditText)v.findViewById(R.id.item_value);
       mValueField.setText(mitem.getValue());
        mValueField.addTextChangedListener(new TextWatcher() {
            public void onTextChanged(
                    CharSequence c, int start, int before, int count) {
                mitem.setValue(c.toString());
            }
            public void beforeTextChanged(
                    CharSequence c, int start, int count, int after) {
                // This space intentionally left blank
            }
            public void afterTextChanged(Editable c) {
                // This one too
            }
        });

        mDateButton = (Button)v.findViewById(R.id.item_date);
        mDateButton.setText(mitem.getDate().toString());
        mDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager manager =
                        getFragmentManager();
                DatePickerFragment dialog =
                        DatePickerFragment
                                .newInstance(mitem.getDate());
                dialog.setTargetFragment(HomeFragment.this,
                        REQUEST_DATE);

                dialog.show(manager, DIALOG_DATE);
            }
        });

        mReportButton = (Button)
                v.findViewById(R.id.item_report);
        mReportButton.setText("Send Report");
        mReportButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new
                        Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT,
                        getCrimeReport());
                i.putExtra(Intent.EXTRA_SUBJECT,
                        getString(R.string.item_report_subject));
                startActivity(i);
            }
        });

        mPhotoButton = (ImageButton)
                v.findViewById(R.id.item_camera);

        PackageManager packageManager = getActivity().getPackageManager();

        final Intent captureImage = new
                Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        boolean canTakePhoto = mPhotoFile != null &&
                captureImage.resolveActivity(packageManager) != null;
           mPhotoButton.setEnabled(canTakePhoto);
        mPhotoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri uri = FileProvider.getUriForFile(getActivity(), "com.example.android.homepwner.fileprovider", mPhotoFile);
                captureImage.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                List<ResolveInfo> cameraActivities =
                        getActivity()
                                .getPackageManager().queryIntentActivities(captureImage,
                                PackageManager.MATCH_DEFAULT_ONLY);
                for (ResolveInfo activity :
                        cameraActivities) {
                    getActivity().grantUriPermission(activity.activityInfo.packageName,
                            uri,
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                }
                startActivityForResult(captureImage,
                        REQUEST_PHOTO);
            }
        });

        mPhotoView = (ImageView)
                v.findViewById(R.id.item_photo);

        updatePhotoView();






        return v;
    }
    @Override
    public void onActivityResult(int requestCode, int
            resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requestCode == REQUEST_DATE) {
            Date date = (Date) data
                    .getSerializableExtra(DatePickerFragment.EXTRA_DATE);
            mitem.setDate(date);
            mDateButton.setText(mitem.getDate().toString());

    } else if (requestCode == REQUEST_PHOTO) {
        Uri uri =
                FileProvider.getUriForFile(getActivity(),
                        "com.bignerdranch.android.criminalintent.fileprovider",
                        mPhotoFile);
        getActivity().revokeUriPermission(uri,
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        updatePhotoView();
    }
    }

    private String getCrimeReport() {
        String solvedString = null;
        if (mitem.isSolved()) {
            solvedString =
                    getString(R.string.item_report_solved);
        } else {
            solvedString =
                    getString(R.string.item_report_unsolved);
        }
        String dateFormat = "EEE, MMM dd";
        String dateString =
                DateFormat.format(dateFormat,
                        mitem.getDate()).toString();
        String suspect = mitem.getSuspect();
      //  if (suspect == null) {
     //       suspect =
     //               getString(R.string.item_report_no_suspect);
     //   } else {
      //      suspect =
      //              getString(R.string.item_report_suspect, suspect);
     //   }
        String report =
                getString(R.string.item_report,
                        mitem.getTitle(), dateString,
                        solvedString, suspect);
        return report;
    }

    private void updateItem() {
       // ItemLab.get(getActivity()).updateItem(mitem);
        mCallbacks.onItemUpdated(mitem);
    }


    private void updatePhotoView() {
        if (mPhotoFile == null ||
                !mPhotoFile.exists()) {
            mPhotoView.setImageDrawable(null);
        } else {
            Bitmap bitmap =
                    PictureUtils.getScaledBitmap(
                            mPhotoFile.getPath(),
                            getActivity());
            mPhotoView.setImageBitmap(bitmap);
        }
    }



}
